//
//  ProfileHeaderView.swift
//  Navigation
//
//  Created by Роман on 05.05.2021.
//  Copyright © 2021 Artem Novichkov. All rights reserved.
//

import UIKit

class ProfileHeaderView: UIView {
    
    let myTitleLabel = UILabel()
    private var statusText: String = " "
    let textField = UITextField()
    let statusButton = UIButton(type: .system)
    let whiteTextField = UITextField()
    let dogImageView: UIImageView = {
           let div = UIImageView()
   //        div.contentMode = .scaleAspectFit
           div.image = #imageLiteral(resourceName: "dachshundPhoto")
           div.clipsToBounds = true
           
           return div
       }()
    
    func addSubviews(){
        addSubview(myTitleLabel)
        addSubview(statusButton)
        addSubview(textField)
        addSubview(dogImageView)
        addSubview(whiteTextField)
    }
    
    @objc private func statusButtonPressed() {
        
     statusTextChanged(whiteTextField)
        textField.text = statusText
     
        guard let text = textField.text else {
            return
        }
       print("\(text)")
    }
    @objc private func statusTextChanged(_ textFieldInternal: UITextField) {
        statusText = textFieldInternal.text!
    }


    
    override init(frame: CGRect) {
        super.init(frame: frame)
   
        dogImageView.layer.borderWidth = 3
        dogImageView.layer.borderColor = UIColor.white.cgColor
        dogImageView.layer.cornerRadius = 75
        
        myTitleLabel.font = UIFont.systemFont(ofSize: 18, weight: .bold)
        myTitleLabel.text = "Coolest Dog Ever"
        myTitleLabel.textColor = .black
//        myTitleLabel.textAlignment = .center
        myTitleLabel.numberOfLines = 0
        
        textField.font = UIFont.systemFont(ofSize: 14, weight: .regular)
        textField.textColor = .gray
        textField.text = "Waiting for something"
        textField.isUserInteractionEnabled = false
        
        statusButton.layer.cornerRadius = 4
        statusButton.layer.shadowOffset = CGSize(width: 4, height: 4)
        statusButton.layer.shadowRadius = 4
        statusButton.layer.shadowColor = UIColor.black.cgColor
        statusButton.layer.shadowOpacity = 0.7
        statusButton.setTitleColor(.white, for: .normal)
        statusButton.setTitle("Show Status", for: .normal)
        statusButton.backgroundColor = .blue
        statusButton.addTarget(self, action: #selector(statusButtonPressed), for: .touchUpInside)
        statusButton.addTarget(self, action: #selector(statusTextChanged), for: .editingChanged)
        
        whiteTextField.backgroundColor = .white
        whiteTextField.font = UIFont.systemFont(ofSize: 15, weight: .regular)
        whiteTextField.textColor = .black
        whiteTextField.layer.cornerRadius = 12
        whiteTextField.layer.borderWidth = 1
        whiteTextField.layer.borderColor = UIColor.black.cgColor
        
        addSubviews()
        
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    
    override func layoutSubviews() {
        super.layoutSubviews()
    
        dogImageView.frame = CGRect(x: 16, y: safeAreaInsets.top + 16, width: 150, height: 150)
        
        myTitleLabel.sizeToFit()
        myTitleLabel.frame = CGRect(x: 16+150+3+16 , y: safeAreaInsets.top + 27, width: frame.width - 201, height: myTitleLabel.frame.height)
        
        textField.sizeToFit()
        textField.frame = CGRect(x: 185, y: 35 - 48 + dogImageView.frame.height + safeAreaInsets.top, width: frame.width - 201 , height: textField.frame.height)

        statusButton.frame = CGRect(x: 16, y: dogImageView.frame.height + safeAreaInsets.top + 9 + 57, width: frame.width - 32 , height: 50)
        
        whiteTextField.frame = CGRect(x: 185, y: dogImageView.frame.height + safeAreaInsets.top - 13 + 24, width: frame.width - 201, height: 40)
        
    }
}
